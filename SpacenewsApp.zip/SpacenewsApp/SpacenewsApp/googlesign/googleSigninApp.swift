//
//  googlwSigninApp.swift
//  SpacenewsApp
//
//  Created by Jayasri  on 21/09/22.
//

//import Foundation
//import GoogleSignIn
//import SwiftUI
////@main
//struct googleSigninApp: App {
//    var body: some Scene {
//        WindowGroup{
//            ContentView()
//
//        }
//    }
//}
//class Appdelegate: NSObject, UIApplicationDelegate {
//    func application(_ application: UIApplication,  didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey : Any]? = nil ) -> Bool {
//        
////        WindowGroup<googleSignin>.configure()
//        return true
//    }
//}

