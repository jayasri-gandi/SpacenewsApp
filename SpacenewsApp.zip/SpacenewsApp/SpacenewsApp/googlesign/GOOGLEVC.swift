//
//  GOOGLEVC.swift
//  SpacenewsApp
//
//  Created by Jayasri  on 21/09/22.
//

//import Foundation
//import SwiftUI
//struct GOOGLEVC: UIViewController {
//
    
    
//}
