//
//  AppilicationUtility.swift
//  SpacenewsApp
//
//  Created by Jayasri  on 21/09/22.
//


//import SwiftUI
//final class AppilicationUtility {
//    
//    static var rootViewController: UIViewController {
//        
////        guard let screen = UIApplication.shared.connectedScenes.first as? UIWindow else {
//            return.init()
//        }
//        
////        guard let root = screen.windows.first?.rootViewController else {
//            return.init()
//        }
//        return root
//    }
//}
