//
//  ContentView.swift
//  SpacenewsApp
//
//  Created by Jayasri  on 20/09/22.
//


import SwiftUI

struct ContentView: View {
    var body: some View {
//        loginScreen()
        spaceAPI()



    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}




