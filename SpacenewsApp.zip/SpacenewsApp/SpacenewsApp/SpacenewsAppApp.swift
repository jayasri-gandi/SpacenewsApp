//
//  SpacenewsAppApp.swift
//  SpacenewsApp
//
//  Created by Jayasri  on 20/09/22.
//

import SwiftUI

@main
struct SpacenewsAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
